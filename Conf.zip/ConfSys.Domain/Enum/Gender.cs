﻿namespace ConfSys.Domain.Enum;

    public enum Gender : byte
    {
        Male = 1,
        Female = 0
    }
