﻿namespace ConfSys.Domain.Enum;

public enum Schema : byte
{
    Base
}
