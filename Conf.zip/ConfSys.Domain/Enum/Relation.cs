﻿namespace ConfSys.Domain.Enum;

public enum Relation : byte
{
    Mother = 0,
    Father = 1,
    Brother = 2,
    Sister = 3,
    Son = 4,
    Daughter = 5,
    Uncle = 6,
    Aunt = 7,
    GrandMother = 8,
    Grandfather = 9
}
