﻿namespace ConfSys.Domain.Enum;

public enum Position : byte
{
    CO = 0,
    CEO = 1,
    Developer = 2,
    CF = 3,
    PO = 4,
    PM = 5
}
