﻿#nullable disable

namespace ConfSys.Domain.Dtos.User;

public class UserLoginDto
{
    public string Email { get; set; }
    public string Password { get; set; }
}
