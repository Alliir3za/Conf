﻿#nullable disable
namespace ConfSys.Domain.Dtos;

public class MemberList
{
    public string Family { get; set; }
    public string Position { get; set; }
    public string Name { get; set; }
    public string ProjectName { get; set; }
    public string Origin { get; set; }  
}
