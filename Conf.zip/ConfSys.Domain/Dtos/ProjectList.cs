﻿#nullable disable
namespace ConfSys.Domain.Dtos;

public class ProjectList
{
    public string Name { get; set; }
    public string Family { get; set; }
    public string Origin { get; set; }
    public string ProjectName { get; set; }
    public string Position { get; set; }
    public DateTime Engagement { get; set; }
}