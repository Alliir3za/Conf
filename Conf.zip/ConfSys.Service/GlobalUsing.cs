﻿global using ConfSys.Data;
global using ConfSys.Service.Interface;
global using Microsoft.EntityFrameworkCore;
global using ConfSys.Domain.Dtos;
