﻿global using ConfSys.Domain.Entity;
