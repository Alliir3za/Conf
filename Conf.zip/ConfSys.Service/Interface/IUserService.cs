﻿using ConfSys.Domain.Entity;

namespace ConfSys.Service.Interface;

public interface IUserService
{
    Task<User> LoginAsync(string email, string password);
    Task<bool> CreateAsync(User model);
}
