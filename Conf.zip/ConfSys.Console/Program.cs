﻿using ConfSys.Domain.Entity;
using ConfSys.Domain.Enum;
using ConfSys.Service.Implement;
using ConfSys.Service.Interface;

IUserService userService = new UserService();

//await userService.CreateAsync(new User
//{
//    Email = "F.Hamidi@gmail.com",
//    Family = "hamidi",
//    Gender = Gender.Male,
//    Name = "Farhad",
//    OriginId = 5,
//});
//var resutl = await userService.LoginAsync("mha.karimi@gmail.com", "418443");
IProjectService projectService = new ProjectService();


//await projectService.DeleteAsync(4, 4);
await projectService.CreateProjectAsync(new Project
{
    UserId = 4,
    Name = "General",
    Website = "faceboo"
});

Console.ReadLine();