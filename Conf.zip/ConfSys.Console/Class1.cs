﻿using ConfSys.Data;
using ConfSys.Domain.Entity;

namespace ConfSys.Console;

public class Class1
{
   
}

