﻿namespace ConfSys
{
    public class Class1
    {

    }
}